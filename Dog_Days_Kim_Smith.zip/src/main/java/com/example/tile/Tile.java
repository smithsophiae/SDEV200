// Tile declaration file
package com.example.tile;

import java.awt.image.BufferedImage;

//declaration
public class Tile {
    public BufferedImage image;
    public boolean collision = false;
}
